# zlib-win-build

zlib Windows build with Visual Studio.

This version is zlib-1.2.11.

See win-build-info for general information about the
win-build effort.

To build, simply open the required solution file, and
you know how to use Visual Studio, right?
(or perhaps this is the wrong place for you.)
